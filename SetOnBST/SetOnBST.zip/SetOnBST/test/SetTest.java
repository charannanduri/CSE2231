import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.set.Set;

/**
 * JUnit test fixture for {@code Set<String>}'s constructor and kernel methods.
 *
 * @author Charan Nanduri and Evan Frisbie
 *
 */
public abstract class SetTest {

    /**
     * Invokes the appropriate {@code Set} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new set
     * @ensures constructorTest = {}
     */
    protected abstract Set<String> constructorTest();

    /**
     * Invokes the appropriate {@code Set} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new set
     * @ensures constructorRef = {}
     */
    protected abstract Set<String> constructorRef();

    /**
     * Creates and returns a {@code Set<String>} of the implementation under
     * test type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsTest = [entries in args]
     */
    private Set<String> createFromArgsTest(String... args) {
        Set<String> set = this.constructorTest();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     * Creates and returns a {@code Set<String>} of the reference implementation
     * type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsRef = [entries in args]
     */
    private Set<String> createFromArgsRef(String... args) {
        Set<String> set = this.constructorRef();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    // TODO - add test cases for constructor, add, remove, removeAny, contains, and size
    //
    @Test
    public void testConstructorNoArgs() {
        Set<String> s = this.constructorTest();
        Set<String> sExp = this.constructorRef();
        assertEquals(sExp, s);
    }

    //add tests

    @Test
    public void testAddToEmptyElement() {
        Set<String> s = this.createFromArgsTest();
        Set<String> sExp = this.createFromArgsRef();
        s.add("red");
        sExp.add("red");
        assertEquals(sExp, s);
    }

    @Test
    public void testAddToExistingElement() {
        Set<String> s = this.createFromArgsTest("yellow", "red", "grey");
        Set<String> sExp = this.createFromArgsRef("yellow", "red", "grey");
        s.add("blue");
        sExp.add("blue");
        assertEquals(sExp, s);
    }

    //remove tests*
    @Test
    public final void testRemoveOne() {
        Set<String> s = this.createFromArgsTest("red");
        Set<String> sExp = this.createFromArgsRef("red");
        String str = s.remove("red");
        String strExp = sExp.remove("red");
        assertEquals(sExp, s);
        assertEquals(strExp, str);
    }

    @Test
    public final void testRemoveMultiple() {
        Set<String> s = this.createFromArgsTest("yellow", "red", "grey",
                "blue");
        Set<String> sExp = this.createFromArgsRef("yellow", "red", "grey",
                "blue");
        String str = s.remove("red");
        String strExp = sExp.remove("red");
        assertEquals(sExp, s);
        assertEquals(strExp, str);
    }

    @Test
    public final void testRemoveEnd() {
        Set<String> s = this.createFromArgsTest("yellow", "red", "grey",
                "blue");
        Set<String> sExp = this.createFromArgsRef("yellow", "red", "grey",
                "blue");
        String str = s.remove("blue");
        String strExp = sExp.remove("blue");
        assertEquals(sExp, s);
        assertEquals(strExp, str);
    }

    @Test
    public final void testRemoveMiddle() {
        Set<String> s = this.createFromArgsTest("yellow", "red", "grey",
                "blue");
        Set<String> sExp = this.createFromArgsRef("yellow", "red", "grey",
                "blue");
        String str = s.remove("grey");
        String strExp = sExp.remove("grey");
        assertEquals(sExp, s);
        assertEquals(strExp, str);
    }

    // removeAny tests
    @Test
    public final void testRemoveAny() {
        Set<String> s = this.createFromArgsTest("red", "grey");
        Set<String> sExp = this.createFromArgsRef("red", "grey");
        String str = s.removeAny();
        assertTrue(sExp.contains(str));
        String strExp = sExp.remove(str);
        assertEquals(sExp, s);
        assertEquals(strExp, str);
    }

    @Test
    public final void testRemoveAnyMakingEmptySet() {
        Set<String> s = this.createFromArgsTest("red");
        Set<String> sExp = this.createFromArgsRef("red");
        String str = s.removeAny();
        assertTrue(sExp.contains(str));
        String strExp = sExp.removeAny();
        assertEquals(sExp, s);
        assertEquals(strExp, str);
    }

    // contains tests

    @Test
    public final void testContainsEmpty() {
        Set<String> s = this.createFromArgsTest();
        Set<String> sExp = this.createFromArgsRef();
        String str = "red";
        assertEquals(sExp.contains(str), s.contains(str));
        assertEquals(sExp, s);
    }

    @Test
    public final void testContainsBoolTrue() {
        Set<String> s = this.createFromArgsTest("red", "grey");
        Set<String> sExp = this.createFromArgsRef("red", "grey");
        String str = "red";
        assertEquals(sExp.contains(str), s.contains(str));
        assertEquals(sExp, s);
    }

    @Test
    public final void testContainsBoolFalse() {
        Set<String> s = this.createFromArgsTest("red", "grey");
        Set<String> sExp = this.createFromArgsRef("red", "grey");
        String str = "blue";
        assertEquals(sExp.contains(str), s.contains(str));
        assertEquals(sExp, s);
    }

    //size test

    @Test
    public final void testSizeZero() {
        Set<String> s = this.constructorTest();
        Set<String> sExp = this.constructorRef();
        assertEquals(s.size(), sExp.size());
        assertEquals(sExp, s);
    }

    @Test
    public final void testSizeOne() {
        Set<String> s = this.createFromArgsTest("red");
        Set<String> sExp = this.createFromArgsRef("red");
        assertEquals(s.size(), sExp.size());
        assertEquals(sExp, s);
    }

    @Test
    public final void testSizeMultiple() {
        Set<String> s = this.createFromArgsTest("yellow", "red", "grey",
                "blue");
        Set<String> sExp = this.createFromArgsRef("yellow", "red", "grey",
                "blue");
        assertEquals(s.size(), sExp.size());
        assertEquals(sExp, s);
    }

}
