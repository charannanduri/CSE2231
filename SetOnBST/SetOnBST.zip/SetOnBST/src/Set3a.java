import java.util.Iterator;

import components.binarytree.BinaryTree;
import components.binarytree.BinaryTree1;
import components.set.Set;
import components.set.SetSecondary;

/**
 * {@code Set} represented as a {@code BinaryTree} (maintained as a binary
 * search tree) of elements with implementations of primary methods.
 *
 * @param <T>
 *            type of {@code Set} elements
 * @mathdefinitions <pre>
 * IS_BST(
 *   tree: binary tree of T
 *  ): boolean satisfies
 *  [tree satisfies the binary search tree properties as described in the
 *   slides with the ordering reported by compareTo for T, including that
 *   it has no duplicate labels]
 * </pre>
 * @convention IS_BST($this.tree)
 * @correspondence this = labels($this.tree)
 *
 * @author Evan Frisbie & Charan Nanduri
 *
 */
public class Set3a<T extends Comparable<T>> extends SetSecondary<T> {

    /*
     * Private members --------------------------------------------------------
     */

    /**
     * Elements included in {@code this}.
     */
    private BinaryTree<T> tree;

    /**
     * Returns whether {@code x} is in {@code t}.
     *
     * @param <T>
     *            type of {@code BinaryTree} labels
     * @param t
     *            the {@code BinaryTree} to be searched
     * @param x
     *            the label to be searched for
     * @return true if t contains x, false otherwise
     * @requires IS_BST(t)
     * @ensures isInTree = (x is in labels(t))
     */
    private static <T extends Comparable<T>> boolean isInTree(BinaryTree<T> t,
            T x) {
        assert t != null : "Violation of: t is not null";
        assert x != null : "Violation of: x is not null";

        //create a boolean to hold our resulting value
        boolean result = false;

        //split into a left and right tree and get size
        BinaryTree<T> l = t.newInstance(), r = t.newInstance();
        int size = t.size();

        //check if we have found our value or recursively call this function to
        //check again
        if (size > 0) {
            T root = t.disassemble(l, r);

            if (root.equals(x)) {
                result = true;
            } else if (root.compareTo(x) < 0) {
                result = isInTree(r, x);
            } else if (root.compareTo(x) > 0) {
                result = isInTree(l, x);
            }

            t.assemble(root, l, r);
        }

        //return our result
        return result;
    }

    /**
     * Inserts {@code x} in {@code t}.
     *
     * @param <T>
     *            type of {@code BinaryTree} labels
     * @param t
     *            the {@code BinaryTree} to be searched
     * @param x
     *            the label to be inserted
     * @aliases reference {@code x}
     * @updates t
     * @requires IS_BST(t) and x is not in labels(t)
     * @ensures IS_BST(t) and labels(t) = labels(#t) union {x}
     */
    private static <T extends Comparable<T>> void insertInTree(BinaryTree<T> t,
            T x) {
        assert t != null : "Violation of: t is not null";
        assert x != null : "Violation of: x is not null";

        // start by getting the tree's size
        int size = t.size();

        //Break down the tree, check values, insert the x in the correct position
        //then reassemble the tree
        if (size != 0) {

            BinaryTree<T> l = t.newInstance(), r = t.newInstance();
            T root = t.disassemble(l, r);

            if (x.compareTo(root) < 0) {
                insertInTree(l, x);
            } else {
                insertInTree(r, x);
            }

            t.assemble(root, l, r);
        } else if (size == 0) {
            //if the tree is empty then create a new tree with just a root x

            BinaryTree<T> lnull = t.newInstance();
            BinaryTree<T> rnull = t.newInstance();

            t.assemble(x, lnull, rnull);
        }

    }

    /**
     * Removes and returns the smallest (left-most) label in {@code t}.
     *
     * @param <T>
     *            type of {@code BinaryTree} labels
     * @param t
     *            the {@code BinaryTree} from which to remove the label
     * @return the smallest label in the given {@code BinaryTree}
     * @updates t
     * @requires IS_BST(t) and |t| > 0
     * @ensures <pre>
     * IS_BST(t)  and  removeSmallest = [the smallest label in #t]  and
     *  labels(t) = labels(#t) \ {removeSmallest}
     * </pre>
     */
    private static <T> T removeSmallest(BinaryTree<T> t) {
        assert t != null : "Violation of: t is not null";
        assert t.size() > 0 : "Violation of: |t| > 0";

        // Create a result of type T
        T result = null;

        //split the tree and disassemble to the root
        BinaryTree<T> l = t.newInstance(), r = t.newInstance();
        T root = t.disassemble(l, r);
        int leftTreeSize = l.size();

        //Until the tree is empty, move down recursively and reassemble on the
        //way out. If it is empty, remove it and set it as the result.
        if (leftTreeSize > 0) {
            result = removeSmallest(l);
            t.assemble(root, l, r);
        } else if (leftTreeSize == 0) {
            result = root;
            t.transferFrom(r);
        }

        //Finally, return the node that was removed.
        return result;
    }

    /**
     * Finds label {@code x} in {@code t}, removes it from {@code t}, and
     * returns it.
     *
     * @param <T>
     *            type of {@code BinaryTree} labels
     * @param t
     *            the {@code BinaryTree} from which to remove label {@code x}
     * @param x
     *            the label to be removed
     * @return the removed label
     * @updates t
     * @requires IS_BST(t) and x is in labels(t)
     * @ensures <pre>
     * IS_BST(t)  and  removeFromTree = x  and
     *  labels(t) = labels(#t) \ {x}
     * </pre>
     */
    private static <T extends Comparable<T>> T removeFromTree(BinaryTree<T> t,
            T x) {
        assert t != null : "Violation of: t is not null";
        assert x != null : "Violation of: x is not null";
        assert t.size() > 0 : "Violation of: x is in labels(t)";

        T removed;
        BinaryTree<T> left = t.newInstance();
        BinaryTree<T> right = t.newInstance();
        T rootNode = t.disassemble(left, right);

        if (x.compareTo(rootNode) < 0) {
            // search through left side of tree
            removed = removeFromTree(left, x);
            // assemble tree
            t.assemble(rootNode, left, right);
        } else if (x.compareTo(rootNode) > 0) {
            // search through right side of tree
            removed = removeFromTree(right, x);
            // reassemble tree
            t.assemble(rootNode, left, right);
        } else { // base case
            removed = rootNode;
            // reassemble tree
            // left most node on right tree becomes root node
            // if right tree is empty, then reassembled tree is just left side
            if (right.size() > 0) {
                t.assemble(removeSmallest(right), left, right);
            } else {
                t.transferFrom(left);
            }
        }

        return removed;
    }

    /**
     * Creator of initial representation.
     */
    private void createNewRep() {

        //just create a representation and save it to the tree value of this
        this.tree = new BinaryTree1<T>();

    }

    /*
     * Constructors -----------------------------------------------------------
     */

    /**
     * No-argument constructor.
     */
    public Set3a() {

        this.createNewRep();

    }

    /*
     * Standard methods -------------------------------------------------------
     */

    @SuppressWarnings("unchecked")
    @Override
    public final Set<T> newInstance() {
        try {
            return this.getClass().getConstructor().newInstance();
        } catch (ReflectiveOperationException e) {
            throw new AssertionError(
                    "Cannot construct object of type " + this.getClass());
        }
    }

    @Override
    public final void clear() {
        this.createNewRep();
    }

    @Override
    public final void transferFrom(Set<T> source) {
        assert source != null : "Violation of: source is not null";
        assert source != this : "Violation of: source is not this";
        assert source instanceof Set3a<?> : ""
                + "Violation of: source is of dynamic type Set3<?>";
        /*
         * This cast cannot fail since the assert above would have stopped
         * execution in that case: source must be of dynamic type Set3a<?>, and
         * the ? must be T or the call would not have compiled.
         */
        Set3a<T> localSource = (Set3a<T>) source;
        this.tree = localSource.tree;
        localSource.createNewRep();
    }

    /*
     * Kernel methods ---------------------------------------------------------
     */

    @Override
    public final void add(T x) {
        assert x != null : "Violation of: x is not null";
        assert !this.contains(x) : "Violation of: x is not in this";

        //Just call our function that will sort and place
        insertInTree(this.tree, x);

    }

    @Override
    public final T remove(T x) {
        assert x != null : "Violation of: x is not null";
        assert this.contains(x) : "Violation of: x is in this";
        /*
         * //Create a T value to hold the result T result = null;
         *
         * //Remove x from the tree and assign result =
         * removeFromTree(this.tree, x);
         */
        //return our value
        return removeFromTree(this.tree, x);
    }

    @Override
    public final T removeAny() {
        assert this.size() > 0 : "Violation of: this /= empty_set";

        //Create a T value to hold the result
        T result = null;

        //Remove the smallest value from the tree and assign
        result = removeSmallest(this.tree);

        //return our value
        return result;
    }

    @Override
    public final boolean contains(T x) {
        assert x != null : "Violation of: x is not null";

        //Create a boolean value to hold the result, initialize to false
        boolean result = false;

        //use isInTree to check if the value is contained.
        result = isInTree(this.tree, x);

        //return our value
        return result;
    }

    @Override
    public final int size() {

        int size = this.tree.size();

        return size;
    }

    @Override
    public final Iterator<T> iterator() {
        return this.tree.iterator();
    }

}
